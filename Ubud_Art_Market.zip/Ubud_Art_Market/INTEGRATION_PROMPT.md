Integrate with the Phase 2 MDX component library.

Before publishing:
- Fetch Google Place ID
- Fetch coordinates
- Fetch live rating & review count
- Verify opening hours
- Validate links and production build
