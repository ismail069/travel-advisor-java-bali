Integrate with the Phase 2 MDX component library.

Before publishing:
- Fetch Google Place ID
- Fetch exact coordinates
- Fetch live rating and review count
- Verify opening hours
- Verify parking, toilets, and payment options
- Validate MDX, internal links, and production build
