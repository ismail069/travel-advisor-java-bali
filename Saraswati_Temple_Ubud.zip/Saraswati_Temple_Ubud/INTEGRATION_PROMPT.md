# Integration Prompt — Saraswati Temple Ubud

Integrate `saraswati-temple-ubud.mdx` using the Phase 2 MDX components.

Retrieve live Google Place ID, coordinates, rating, and review count. Confirm admission, hours, dress rules, and performance schedule. Validate MDX, Maps links, internal routes, and production build.
