# Saraswati Temple Ubud

Included:

- `saraswati-temple-ubud.mdx`
- `README.md`
- `INTEGRATION_PROMPT.md`
