# Ubud Palace
