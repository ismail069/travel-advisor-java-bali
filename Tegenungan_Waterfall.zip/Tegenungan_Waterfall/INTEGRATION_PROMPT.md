Integrate with the Phase 2 MDX component library.

Before publishing:
- Fetch Google Place ID
- Fetch coordinates
- Fetch live Google rating & review count
- Verify ticket price
- Verify opening hours
- Validate MDX and production build
