# Silayukti Temple

- silayukti-temple.mdx
- README.md
- INTEGRATION_PROMPT.md
