# Integration Prompt — Neka Art Museum

Integrate `neka-art-museum.mdx`.

Requirements:

- Use the Phase 2 MDX component library.
- Retrieve live Google Place ID, precise coordinates, rating, and review count.
- Confirm current admission and photography policy.
- Verify pavilion accessibility and parking.
- Validate Museum JSON-LD, Maps links, MDX, and internal routes.
- Do not publish artwork photographs without rights clearance.
- Run lint, type-check, tests, and production build.
