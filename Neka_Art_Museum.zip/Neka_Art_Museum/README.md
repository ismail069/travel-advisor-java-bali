# Neka Art Museum

Included:

- `neka-art-museum.mdx`
- `README.md`
- `INTEGRATION_PROMPT.md`

Live fields requiring verification:

- Admission fee
- Photography rules
- Temporary exhibitions
- Google Place ID
- Coordinates
- Google rating and review count
- Accessibility and parking
