Integrate using Phase 2 MDX components.
Fetch Google Place ID, coordinates, rating, review count, admission, opening hours, and validate production build.
