Integrate with Phase 2 MDX components.
Fetch Google Place ID, coordinates, live rating, review count, and validate all links before production.
