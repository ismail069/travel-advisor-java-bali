Integrate this destination with the Phase 2 MDX component library.

Before publishing:
- Fetch and verify Google Place ID
- Fetch exact coordinates
- Fetch live Google rating and review count
- Verify access hours, fees, and official naming
- Verify waves, currents, tides, and seasonal sea conditions
- Verify parking, toilets, food stalls, equipment rental, and accessibility
- Verify photography and drone restrictions
- Add validated TouristAttraction or Beach JSON-LD
- Add internal links to Padangbai and nearby destinations
- Validate MDX syntax and the production build
