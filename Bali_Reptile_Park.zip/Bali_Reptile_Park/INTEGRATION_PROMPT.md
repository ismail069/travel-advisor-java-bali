Integrate with the Phase 2 MDX component library.

Before publishing:
- Fetch Google Place ID
- Fetch exact coordinates
- Fetch live Google rating and review count
- Verify admission prices and opening hours
- Verify current animal programs and encounter policies
- Verify accessibility, parking, toilets, and family facilities
- Verify commercial photography rules
- Validate MDX, internal links, JSON-LD, and production build
