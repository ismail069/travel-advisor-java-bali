Integrate this destination with the Phase 2 MDX component library.

Before publishing:
- Fetch and verify Google Place ID
- Fetch exact coordinates
- Fetch live Google rating and review count
- Verify opening hours, donation, and official naming
- Verify guide, weaving workshop, and craft-shop availability
- Verify accessibility, parking, toilets, and visitor facilities
- Verify ceremony, photography, drone, and textile-use restrictions
- Add validated TouristAttraction or Place JSON-LD
- Add internal links to nearby East Bali destinations
- Validate MDX syntax and the production build
